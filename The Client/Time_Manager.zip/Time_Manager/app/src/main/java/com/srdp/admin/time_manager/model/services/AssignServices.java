package com.srdp.admin.time_manager.model.services;

/**
 * Created by admin on 2018/4/15.
 */

public class AssignServices {
    public void appendAssignTable(){};
}
