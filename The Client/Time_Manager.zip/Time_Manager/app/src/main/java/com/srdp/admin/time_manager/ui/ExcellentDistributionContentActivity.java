package com.srdp.admin.time_manager.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

/*import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.ashokvarma.bottomnavigation.BottomNavigationItem;
import com.ashokvarma.bottomnavigation.behaviour.BottomNavBarFabBehaviour;
import com.ashokvarma.bottomnavigation.behaviour.BottomVerticalScrollBehavior;
import com.ashokvarma.bottomnavigation.utils.Utils;*/
import com.srdp.admin.time_manager.R;

public class ExcellentDistributionContentActivity extends AppCompatActivity {

    //private BottomNavigationBar mbottomNavigationBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excellent_distribution_content);

        //底部按钮
        //mbottomNavigationBar = (BottomNavigationBar) findViewById(R.id.bottom_navigation_bar);
        //mbottomNavigationBar.setActiveColor("#e6992f") //设置选中的颜色
//                .setInActiveColor("#e6992f")
//                .addItem(new BottomNavigationItem(R.drawable.like_btn, "赞"))
//                .addItem(new BottomNavigationItem(R.drawable.collect_btn, "收藏"))
//                .initialise();//所有的设置需在调用该方法前完成
    }

}
