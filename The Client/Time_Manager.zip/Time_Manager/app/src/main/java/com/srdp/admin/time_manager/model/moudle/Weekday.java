package com.srdp.admin.time_manager.model.moudle;

public enum Weekday 
{
	Monday,
	Tuesday,
	Wednesday,
	Thursday,
	Friday,
	Saturday,
	Sunday;
}
