package com.srdp.admin.time_manager.http;

import android.os.Handler;

/**
 * Created by admin on 2018/4/15.
 */

public interface GetRequest {
    public void requestByGet(final Handler handler);
}
