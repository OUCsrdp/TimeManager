package com.srdp.admin.time_manager.http;

import android.os.Handler;

/**
 * Created by admin on 2018/4/15.
 */

public interface PostRequest {
    public void requestByPost(final Handler handler);
}
