package com.srdp.admin.time_manager.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.srdp.admin.time_manager.R;

public class ReportFormDayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_form_day);
    }
}
